"use strict";
var chat_component_1 = require('./chat.component');
exports.ChatComponent = chat_component_1.ChatComponent;
//# sourceMappingURL=index.js.map